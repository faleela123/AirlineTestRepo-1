import java.util.*;

 

public class ParseLispExpression {

    public static void main(String args[]) {

      ParseLispExpression parseLispExpression = new ParseLispExpression();

        String expression = "(let x 2 (mult x (let x 3 y 4 (add x y))))";

        int result = parseLispExpression.evaluate(expression);

        System.out.println("expression - "+expression +", result: "+result);

 

        expression = "(let x 3 x 2 x)";

        result = parseLispExpression.evaluate(expression);

        System.out.println("expression - "+expression +", result: "+result);

 

        expression = "(let x 1 y 2 x (add x y) (add x y))";

        result = parseLispExpression.evaluate(expression);

        System.out.println("expression - "+expression +", result: "+result);

 

        expression = "(let x 2 (add (let x 3 (let x 4 x)) x))";

        result = parseLispExpression.evaluate(expression);

        System.out.println("expression - "+expression +", result: "+result);

 

        expression = "(let a1 3 b2 (add a1 1) b2)";

        result = parseLispExpression.evaluate(expression);

        System.out.println("expression - "+expression +", result: "+result);

    }

 

 

public int evaluate(String expression) {

        return evaluate(expression, new HashMap<>());

    }

 

    private int evaluate(final String e, Map<String, Integer> prevScope) {

        if (Character.isDigit(e.charAt(0)) || e.charAt(0) == '-')

            return Integer.parseInt(e);

        if (prevScope.containsKey(e))

            return prevScope.get(e);

 

        Map<String, Integer> scope = new HashMap<>();

        scope.putAll(prevScope);

 

        final int spaceIndex = e.indexOf(' ');

        final String nextExpression = e.substring(spaceIndex + 1, e.length() - 1); // -2: "()"

        List<String> tokens = split(nextExpression);

 

        if (e.startsWith("(m")) // mult

            return evaluate(tokens.get(0), scope) * evaluate(tokens.get(1), scope);

        if (e.startsWith("(a")) // add

            return evaluate(tokens.get(0), scope) + evaluate(tokens.get(1), scope);

 

        // let

        for (int i = 0; i < tokens.size() - 2; i += 2)

            scope.put(tokens.get(i), evaluate(tokens.get(i + 1), scope));

        return evaluate(tokens.get(tokens.size() - 1), scope);

    }

 

    private List<String> split(final String s) {

        List<String> tokens = new ArrayList<>();

        StringBuilder sb = new StringBuilder();

        int parenthesis = 0;

 

        for (char c : s.toCharArray()) {

            if (c == '(')

                ++parenthesis;

            else if (c == ')')

                --parenthesis;

            if (parenthesis == 0 && c == ' ') {

                tokens.add(sb.toString());

                sb.setLength(0);

            } else {

                sb.append(c);

            }

        }

 

        if (sb.length() > 0)

            tokens.add(sb.toString());

        return tokens;

    }

}