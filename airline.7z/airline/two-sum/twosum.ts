
/**
 * @param {number[]} nums
 * @param {number} target
 * @return {number[]}
 */
var twoSum = function(nums, target) {
   // nums = [2,7,11,15]
    //target = 9;
    let hashmap = new Map;
    for(let i=0;i<nums.length;i++){
        let lhs = nums[i];
        let rhs = target - lhs;
        if(hashmap.has(rhs)){
            return [hashmap.get(rhs), i]
        }
        hashmap.set(lhs, i)
        }
    }
    console.log(twoSum([2,7,11,15], 9));
    console.log(twoSum([3,2,4], 6));
    console.log(twoSum([3,3], 6));
    
    
